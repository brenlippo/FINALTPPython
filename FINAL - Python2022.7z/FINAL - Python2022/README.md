# Proyecto Curso Python 2022 - AppBanco 

## Contenido
- Contiene 3 modelos/entidades: clientes, productos y sucursales 
- Se crearon/configuraron formularios, views, templates, herencias, urls para acceder a todas las utilidades de la web
- Generamos CRUD para la entidad Clientes, sumando tambien un Agregar Clientes en caso de que se desee
- Se genero la posibilidad de login, logout y registro de usuario

Finalmente, generamos una ppt explicando las funcionalidades de la web creada y una breve mención sobre sus creadores 


